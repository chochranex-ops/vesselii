local spell, super = Class(Spell, "elem_blade")

function spell:init()
    super.init(self)

    -- Display name
    self.name = "Elem.Blade"
    -- Name displayed when cast (optional)
    self.cast_name = "Elemental Blade"

    -- Battle description
    self.effect = "Elec/Fire\nDMG&S.Wave"
    -- Menu description
    self.description = "Strike an enemy upwards and send them downwards for shockwave damage. Utilizes Elec/Fire."

    -- TP cost
    self.cost = 24

    -- Target mode (ally, party, enemy, enemies, or none)
    self.target = "enemy"

    -- Tags that apply to this spell
    self.tags = {"damage"}
end

function spell:onCast(user, target)
    target:hurt(((user.chara:getStat("attack"))*(user.chara:getStat("magic")))/1.5)
end

return spell