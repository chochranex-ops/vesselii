local Squeak, super = Class(Event)

function Squeak:init(data)
    super.init(self, data)
end

return Squeak