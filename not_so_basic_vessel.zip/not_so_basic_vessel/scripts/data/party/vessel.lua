local character, super = Class(PartyMember, "vessel")

function character:init()
    super.init(self)

    -- Display name
    self.name = Game.save_name

    -- Actor (handles overworld/battle sprites)
    self:setActor("vessel")
    self:setLightActor("vessel")
    self:setDarkTransitionActor("kris_dark_transition")

    -- Display level (saved to the save file)
    self.level = Game.chapter
    -- Default title / class (saved to the save file)
    self.title = "A human being.\nContains a\nhuman SOUL."

    -- Determines which character the soul comes from (higher number = higher priority)
    self.soul_priority = 2
    -- The color of this character's soul (optional, defaults to red)
    self.soul_color = {1, 0, 0}

    -- Whether the party member can act / use spells
    self.has_act = true
    self.has_spells = false

    -- Whether the party member can use their X-Action
    self.has_xact = false
    -- X-Action name (displayed in this character's spell menu)
    self.xact_name = "Action"

    -- Spells
--    self:addSpell("rude_buster")

    -- Current health (saved to the save file)
    if Game.chapter == 1 then
        self.health = 90
    elseif Game.chapter == 2 then
        self.health = 120
    elseif Game.chapter == 3 then
        self.health = 160
    else
        self.health = 200
    end

    -- Base stats (saved to the save file)
    if Game.chapter == 1 then
        self.stats = {
            health = 90,
            attack = 10,
            defense = 2,
            magic = 1
        }
    elseif Game.chapter == 2 then
        self.stats = {
            health = 120,
            attack = 12,
            defense = 2,
            magic = 2
        }
    elseif Game.chapter == 3 then
        self.stats = {
            health = 160,
            attack = 14,
            defense = 2,
            magic = 3
        }
    else
        self.stats = {
            health = 200,
            attack = 17,
            defense = 2,
            magic = 4
        }

    end
    -- Max stats from level-ups
    if Game.chapter == 1 then
        self.max_stats = {
            health = 120
        }
    elseif Game.chapter == 2 then
        self.max_stats = {
            health = 160
        }
    elseif Game.chapter == 3 then
        self.max_stats = {
            health = 200
        }
    else
        self.max_stats = {
            health = 240
        }
    end
    
    -- Party members which will also get stronger when this character gets stronger, even if they're not in the party
    self.stronger_absent = {"noelle","susie","ralsei"}

    -- Weapon icon in equip menu
    self.weapon_icon = "ui/menu/equip/sword"

    -- Equipment (saved to the save file)
    if Game.chapter <= 2 then
        self:setWeapon("wood_blade")
        if Game.chapter == 2 then
            self:setArmor(1, "amber_card")
            self:setArmor(2, "amber_card")
        end
    elseif Game.chapter == 3 then
        self:setWeapon("mechasaber")
        self:setArmor(1, "amber_card")
        self:setArmor(2, "glowwrist")
    elseif Game.chapter >= 4 then
        self:setWeapon("saber10")
        self:setArmor(1, "gingerguard")
        self:setArmor(2, "glowwrist")
    end

    -- Default light world equipment item IDs (saves current equipment)
    if Game.chapter <= 2 then
        self.lw_weapon_default = "light/pencil"
    elseif Game.chapter == 3 then
        self.lw_weapon_default = "light/mech_pencil"
    elseif Game.chapter >= 4 then
        self.lw_weapon_default = "light/cactusneedle"
    end
    self.lw_armor_default = "light/bandage"

    -- Character color (for action box outline and hp bar)
    self.color = {195/255, 195/255, 195/255}
    -- Damage color (for the number when attacking enemies) (defaults to the main color)
    self.dmg_color = {1, 0, 0}
    -- Attack bar color (for the target bar used in attack mode) (defaults to the main color)
    self.attack_bar_color = {195/255, 195/255, 195/255}
    -- Attack box color (for the attack area in attack mode) (defaults to darkened main color)
    self.attack_box_color = {0, 0, 195/255}
    -- X-Action color (for the color of X-Action menu items) (defaults to the main color)
    self.xact_color = {1, 0, 0}

    -- Head icon in the equip / power menu
    self.menu_icon = "party/vessel/head"
    -- Path to head icons used in battle
    self.head_icons = "party/vessel/icon"

    -- Name sprite
    self.name_sprite = nil

    -- Effect shown above enemy after attacking it
    self.attack_sprite = "effects/attack/cut"
    -- Sound played when this character attacks
    self.attack_sound = "laz_c"
    -- Pitch of the attack sound
    self.attack_pitch = 1

    -- Battle position offset (optional)
    self.battle_offset = {2, 1}
    -- Head icon position offset (optional)
    self.head_icon_offset = nil
    -- Menu icon position offset (optional)
    self.menu_icon_offset = nil

    -- Message shown on gameover (optional)
    self.gameover_message = nil
end

function character:onLevelUp(level)
    self:increaseStat("health", 2)
    if level % 10 == 0 then
        self:increaseStat("attack", 1)
    end
end

function character:getGameOverMessage(main)
    local determined = main:getName().."![wait:10]\nStay determined..."
    return Utils.pick({{"You cannot give\nup just yet...", determined}, {"You're going to\nbe alright!", determined}, {"It cannot end\nnow!", determined}, {"Don't lose hope!", determined}, {"Our fate rests\nupon you...", determined}})
end

function character:drawPowerStat(index, x, y, menu)

end

function character:getName()
    return Game and Game.save_name:sub(1,6) or "You"
end

return character
